"""Review probes for tutorials/bart_zero_shot_classification_colab.ipynb (prefix ZSC).

Run from any working directory:  python run_probes.py <worktree> <banking77_cache_dir>
Writes results.json and source_manifest.json next to this file.

Evidence basis: direct execution on CPU (Windows), no GPU, no model download. Model-backed probes use a TINY
RANDOMLY INITIALISED BartForSequenceClassification built from the pinned snapshot's own config.json (12 decoder
layers kept, widths shrunk) and the snapshot's real tokenizer files, staged with a manifest of its own digests.
The notebook's carried module cells (9, 11, 13) and learner cells (7, 17-31) are executed VERBATIM from the
notebook JSON in one namespace, as the isolated worker would; only form-field literals are substituted (as an
executor sets fields) and two stand-in substitutions are made and labelled: Section 3 (cell 15, which would
download the real 1.6 GB checkpoint) is replaced by loading the stand-in, and the carried WEIGHT_SHA256 constant
is set to the stand-in's digest so the artifact boundary accepts it. The stand-in exercises the carried control
flow, not BART-large-MNLI's numerics.
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
WT = Path(sys.argv[1]).resolve()
B77 = Path(sys.argv[2]).resolve()
NB_PATH = WT / "tutorials" / "bart_zero_shot_classification_colab.ipynb"
RESULTS: dict = {}


def record(key, value):
    RESULTS[key] = value
    (HERE / "results.json").write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")
    print(f"[{key}]", json.dumps(value, default=str)[:600])


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
CELLS = ["".join(c["source"]) for c in nb["cells"]]

# ---- P0: static ------------------------------------------------------------------------------------
code_idx = [i for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]
compiled = {}
for i in code_idx:
    try:
        compile(CELLS[i], f"cell{i}", "exec")
        compiled[i] = True
    except SyntaxError as exc:
        compiled[i] = str(exc)
blob = subprocess.run(["git", "-C", str(WT), "hash-object", str(NB_PATH)], capture_output=True, text=True).stdout.strip()
gen = subprocess.run([sys.executable, str(WT / "tools" / "build_notebook.py"), "--check"], cwd=WT, capture_output=True, text=True)
val = subprocess.run([sys.executable, str(WT / "tools" / "validate_release_assets.py")], cwd=WT, capture_output=True, text=True)
record("P0_static", {
    "n_cells": len(CELLS), "n_code_cells": len(code_idx), "all_compile": all(v is True for v in compiled.values()),
    "notebook_blob": blob, "metadata_dimer": nb["metadata"].get("dimer"),
    "generator_check_exit": gen.returncode, "generator_check_tail": (gen.stdout + gen.stderr)[-300:],
    "validator_exit": val.returncode, "validator_tail": (val.stdout + val.stderr)[-300:],
    "persisted_outputs": sum(1 for c in nb["cells"] if c.get("outputs")),
})

# ---- P1: isolated-runtime construction (static + uv on Windows) -------------------------------------
c3, c5 = CELLS[3], CELLS[5]
p1 = {
    "venv_python_source": re.search(r"uv, \"venv\".*", c3).group(0),
    "uses_managed_python": "--managed-python" in c3,
    "uses_require_hashes": "--require-hashes" in c3,
    "isolated_python_path_expr": re.search(r"ISOLATED_PYTHON = .*", c3).group(0),
    "router_posix_only_args": [a for a in ("pass_fds=", "start_new_session=True") if a in c5],
    "pins_count": c3.count("=="),
}
uv = shutil.which("uv")
if uv:
    with tempfile.TemporaryDirectory() as tmp:
        env_dir = Path(tmp) / "dimer_isolated_env"
        r = subprocess.run([uv, "venv", "--quiet", "--python", sys.executable, str(env_dir)], capture_output=True, text=True)
        p1["windows_uv_venv"] = {
            "uv_version": subprocess.run([uv, "--version"], capture_output=True, text=True).stdout.strip(),
            "exit": r.returncode, "bin/python exists": (env_dir / "bin" / "python").is_file(),
            "Scripts/python.exe exists": (env_dir / "Scripts" / "python.exe").is_file(),
        }
record("P1_isolated_runtime", p1)

# ---- P2: stale learner-facing text ------------------------------------------------------------------
readme = (WT / "tutorials" / "README.md").read_text(encoding="utf-8")
relver = (WT / "docs" / "release-verification.md").read_text(encoding="utf-8")
validator_src = (WT / "tools" / "validate_release_assets.py").read_text(encoding="utf-8")
record("P2_stale_text", {
    "cell6_mentions_install_and_restart": ("installed directly" in CELLS[6], "restart instruction" in CELLS[6]),
    "cell7_runs_pip_install_unless_skip": "pip', 'install'" in CELLS[7],
    "tutorials_readme_runall_column": re.search(r"\| pending[^|]*\|", readme).group(0) if re.search(r"\| pending[^|]*\|", readme) else None,
    "release_verification_records_colab_pass_same_blob": "f652fd671322" in relver and "**PASSED** — 15/15" in relver,
    "release_verification_step_list_mentions_restart_guard": "restart-on-stale-import guard" in relver,
    "ci_step_label": re.search(r"NOTEBOOK_SPEC 2\.\d PAR3", (WT / ".github/workflows/ci.yml").read_text(encoding="utf-8")).group(0),
})

# ---- stand-in snapshot -------------------------------------------------------------------------------
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")
import torch  # noqa: E402
from transformers import BartConfig, BartForSequenceClassification  # noqa: E402

WORK = Path(tempfile.mkdtemp(prefix="zsc_probe_"))
os.chdir(WORK)
snap = WORK / "weights" / "bart-large-mnli"
snap.mkdir(parents=True)
for name in ("README.md", "merges.txt", "tokenizer.json", "tokenizer_config.json", "vocab.json"):
    shutil.copy2(WT / "weights" / "bart-large-mnli" / name, snap / name)
cfg = BartConfig.from_pretrained(WT / "weights" / "bart-large-mnli")
cfg.update({"d_model": 16, "encoder_ffn_dim": 32, "decoder_ffn_dim": 32, "encoder_attention_heads": 2,
            "decoder_attention_heads": 2, "encoder_layers": 1, "decoder_layers": 12, "dropout": 0.0})
torch.manual_seed(0)
BartForSequenceClassification(cfg).save_pretrained(snap, safe_serialization=True)
files = [{"path": p.name, "bytes": p.stat().st_size, "sha256": sha256(p)} for p in sorted(snap.iterdir()) if p.is_file()]
STANDIN_SHA = next(f["sha256"] for f in files if f["path"] == "model.safetensors")
(snap / "dimer-base-manifest.json").write_text(json.dumps({
    "format": "dimer_hf_snapshot", "formatVersion": 1, "modelKey": "bart-large-mnli", "modelId": "facebook/bart-large-mnli",
    "revision": "d7645e127eaf1aefc7862fd59a17a5aa8558b8ce", "files": files, "totalBytes": sum(f["bytes"] for f in files)}), encoding="utf-8")
(WORK / "weights" / "banking77").mkdir(parents=True)
for name in ("train.csv", "test.csv"):
    shutil.copy2(B77 / name, WORK / "weights" / "banking77" / name)


class FakeFiles:
    payload: dict = {}

    @staticmethod
    def upload():
        return dict(FakeFiles.payload)


_google = types.ModuleType("google"); _google.__path__ = []
_colab = types.ModuleType("google.colab"); _colab.files = FakeFiles
sys.modules.setdefault("google", _google); sys.modules["google"].colab = _colab; sys.modules["google.colab"] = _colab


def set_field(src: str, name: str, value) -> str:
    new, n = re.subn(rf"^{name} = .*?(  # @param.*)$", lambda m: f"{name} = {value!r}{m.group(1)}", src, flags=re.M)
    if n != 1:
        raise RuntimeError(f"form field {name} not found exactly once")
    return new


def run_cell(ns, idx, fields=None, quiet=True):
    src = CELLS[idx]
    for k, v in (fields or {}).items():
        src = set_field(src, k, v)
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf if quiet else old
    try:
        exec(compile(src, f"<cell {idx}>", "exec"), ns)
        return {"ok": True, "out": buf.getvalue()}
    except BaseException as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:400], "out": buf.getvalue()[-400:]}
    finally:
        sys.stdout = old


def fresh_namespace():
    ns = {"__name__": "__main__", "display": print}
    for i in (7, 9, 11, 13):
        r = run_cell(ns, i)
        if not r["ok"]:
            raise RuntimeError(f"cell {i}: {r['error']}")
    ns["WEIGHT_SHA256"] = STANDIN_SHA  # stand-in substitution (labelled)
    # Section 3 replacement (stand-in): same calls as cell 15 minus writing the real manifest and the download.
    ns["WEIGHTS_DIR"] = ns["DEFAULT_WEIGHTS_DIR"]
    ns["fetched"] = ns["stage_missing_files"](ns["WEIGHTS_DIR"], allow_download=False)
    ns["snapshot"] = ns["verify_snapshot"](ns["WEIGHTS_DIR"])
    ns["pipe"] = ns["BARTZeroShotClassificationPipeline"].from_pretrained(weights_dir=ns["WEIGHTS_DIR"], device="cpu")
    return ns


FAST = {"LEARNING_RATE": 1e-3, "EPOCHS": 2}  # executor-set form values so the random stand-in actually moves


def decoder_tensor(pipe, layer):
    return pipe._model.state_dict()[f"model.decoder.layers.{layer}.fc2.weight"].detach().clone()


# ---- P3: default path then the prescribed reruns -------------------------------------------------
t0 = time.perf_counter()
ns = fresh_namespace()
base10, base11 = decoder_tensor(ns["pipe"], 10), decoder_tensor(ns["pipe"], 11)
default = {}
for i in (17, 19, 21, 23, 25, 27, 29, 31):
    r = run_cell(ns, i, FAST if i == 23 else None)
    default[i] = r["ok"] if r["ok"] else r["error"]
default_summary = {
    "cells": default,
    "frozen_test_adapted_flag": ns["frozen_test"]["adapted"],
    "best_epoch": ns["adapt_result"]["best_epoch"],
    "history": [{k: e.get(k) for k in ("epoch", "note")} | {"val_acc": e["val"]["accuracy"] if e.get("val") else None} for e in ns["adapt_result"]["history"]],
    "layer11_changed_by_adapt": not torch.equal(base11, decoder_tensor(ns["pipe"], 11)),
    "reload_parity": ns.get("parity"),
    "wording_activity_checkpoint": ns["wording_activity"].get("checkpoint"),
    "seconds": round(time.perf_counter() - t0, 1),
}
record("P3a_default_path_standin", default_summary)

# Rerun as instructed (BYOD instruction / TEMPLATE experiment): "re-run from that cell" = Section 4 onwards.
adapted_before_rerun = decoder_tensor(ns["pipe"], 11)
first_frozen_acc = ns["frozen_test"]["accuracy"]
rerun = {}
for i in (17, 19, 21):
    r = run_cell(ns, i, {"TEMPLATE": "This message is about {}."} if i == 17 else None)
    rerun[i] = r["ok"] if r["ok"] else r["error"]
reference = ns["BARTZeroShotClassificationPipeline"].from_pretrained(weights_dir=ns["WEIGHTS_DIR"], device="cpu")
true_pretrained = reference.evaluate(ns["test_records"], ns["labels"], hypothesis_template=ns["TEMPLATE"])
sec6 = ns["frozen_test"]
diff_preds = sum(a["predicted"] != b["predicted"] for a, b in zip(sec6["predictions"], true_pretrained["predictions"]))
max_score_diff = max(abs(a["scores"][lab] - b["scores"][lab]) for a, b in zip(sec6["predictions"], true_pretrained["predictions"]) for lab in ns["labels"])
r23 = run_cell(ns, 23, FAST)
hist = ns["adapt_result"]["history"]
record("P3b_rerun_from_section4", {
    "cells": rerun | {23: r23["ok"] if r23["ok"] else r23["error"]},
    "section6_labelled": "pretrained_test (cell 21 prints it as pretrained)",
    "section6_evaluate_adapted_flag": sec6["adapted"],
    "section6_vs_true_pretrained": {"prediction_differences_of_200": diff_preds, "max_score_difference": max_score_diff,
                                     "section6_accuracy": sec6["accuracy"], "true_pretrained_accuracy": true_pretrained["accuracy"]},
    "second_adapt_epoch0_note": hist[0].get("note"),
    "second_adapt_starts_from_adapted_weights": not torch.equal(base11, adapted_before_rerun),
})
del reference

# ---- P4: TRAINABLE_DECODER_LAYERS = 1 experiment after the default run ---------------------------
ns = fresh_namespace()
for i in (17, 19, 21, 23, 25, 27, 29, 31):
    r = run_cell(ns, i, FAST if i == 23 else None)
    assert r["ok"], (i, r)
layer10_after_default = decoder_tensor(ns["pipe"], 10)
exp = {}
for i in (23, 25, 27, 29, 31):
    fields = dict(FAST, TRAINABLE_DECODER_LAYERS=1) if i == 23 else None
    r = run_cell(ns, i, fields)
    exp[i] = r["ok"] if r["ok"] else r["error"]
manifest = json.loads((Path("outputs/bart_zero_shot_classification_adapter") / "manifest.json").read_text(encoding="utf-8"))
reloaded = ns["BARTZeroShotClassificationPipeline"].from_artifact("outputs/bart_zero_shot_classification_adapter", weights_dir=ns["WEIGHTS_DIR"], device="cpu")
record("P4_one_layer_experiment_rerun_from_section7", {
    "cells": exp,
    "pipe_layer10_still_first_run_weights": torch.equal(layer10_after_default, decoder_tensor(ns["pipe"], 10)),
    "pipe_layer10_differs_from_base": not torch.equal(base10, decoder_tensor(ns["pipe"], 10)),
    "artifact_decoder_layers_in_tensors": sorted({int(m.group(1)) for t in manifest["tensors"] for m in [re.match(r"model\.decoder\.layers\.(\d+)\.", t)] if m}),
    "reloaded_layer10_equals_base": torch.equal(base10, decoder_tensor(reloaded, 10)),
    "parity_in_namespace": ns.get("parity"),
})
# Control: the same experiment from a fresh start (restart + Run all with the field changed) keeps parity.
ns = fresh_namespace()
ctrl = {}
for i in (17, 19, 21, 23, 25, 27, 29, 31):
    fields = dict(FAST, TRAINABLE_DECODER_LAYERS=1) if i == 23 else None
    r = run_cell(ns, i, fields)
    ctrl[i] = r["ok"] if r["ok"] else r["error"]
record("P4c_one_layer_experiment_fresh_control", {"cells": ctrl, "parity": ns.get("parity")})


# ---- P5: BYOD intake (Section 4, cell 17 executed verbatim with USE_BYOD=True and a fake upload) --------
def byod_payload(n_per_label: dict, long_texts: int = 0, long_label: str | None = None):
    rows = ["id,text,label"]
    k = 0
    for label, n in n_per_label.items():
        for j in range(n):
            text = f"message {k} about {label} number {j}"
            if long_label == label and j < long_texts:
                text = (" ".join(f"ref{i}x{k}" for i in range(900)))[:6000]  # dense tokens, under 8,000 chars
            rows.append(f"r{k:05d},\"{text}\",{label}")
            k += 1
    return ("\n".join(rows) + "\n").encode("utf-8")


ns = fresh_namespace()
p5 = {"minimum_scan": {}}
for n_labels in (2, 10):
    passing = None
    first_fail_msg = None
    for per in range(1, 60):
        FakeFiles.payload = {"byod.csv": byod_payload({f"category {c}": per for c in range(n_labels)})}
        r = run_cell(ns, 17, {"USE_BYOD": True})
        if r["ok"]:
            passing = per * n_labels
            break
        first_fail_msg = r["error"] if per * n_labels >= 8 and first_fail_msg is None else first_fail_msg
        p5.setdefault("rejections", {})[f"{n_labels}x{per}"] = r["error"]
    p5["minimum_scan"][f"{n_labels}_labels_balanced"] = {"stated_minimum": 8, "smallest_passing_total": passing,
                                                       "example_rejection": first_fail_msg}
# A rare category: passes Section 4, then where does it fail?
FakeFiles.payload = {"byod.csv": byod_payload({"category a": 40, "category b": 40, "category rare": 1})}
r17 = run_cell(ns, 17, {"USE_BYOD": True})
rare = {"cell17": r17["ok"] if r17["ok"] else r17["error"]}
if r17["ok"]:
    rare["labels_from_train"] = ns["labels"]
    rare["rare_in_splits"] = {k: sum(r["label"] == "category rare" for r in v) for k, v in ns["splits"].items()}
    r19 = run_cell(ns, 19)
    rare["cell19"] = r19["ok"] if r19["ok"] else r19["error"]
    r21 = run_cell(ns, 21)
    rare["cell21"] = r21["ok"] if r21["ok"] else r21["error"]
p5["rare_category"] = rare
# Over-ceiling texts: 6,000 characters pass the 8,000-character guard.
ns = fresh_namespace()
FakeFiles.payload = {"byod.csv": byod_payload({"category a": 30, "category b": 30}, long_texts=6, long_label="category a")}
r17 = run_cell(ns, 17, {"USE_BYOD": True})
long = {"cell17": r17["ok"] if r17["ok"] else r17["error"]}
if r17["ok"]:
    long["long_records_per_split"] = {k: sum(len(r["text"]) > 5000 for r in v) for k, v in ns["splits"].items()}
    r19 = run_cell(ns, 19)
    long["cell19"] = r19["ok"] if r19["ok"] else r19["error"]
    r21 = run_cell(ns, 21)
    long["cell21"] = r21["ok"] if r21["ok"] else r21["error"]
    long["cell21_error_names_record_id"] = bool(re.search(r"r\d{5}", long["cell21"])) if isinstance(long["cell21"], str) else None
    long_rec = next(r for r in ns["splits"]["validation"] + ns["splits"]["train"] if len(r["text"]) > 5000)
    long["long_record_chars"] = len(long_rec["text"])
    long["long_pair_tokens"] = int(ns["pipe"]._tokenizer(long_rec["text"], ns["TEMPLATE"].format("category a"), return_tensors="pt")["attention_mask"].sum())
    r23 = run_cell(ns, 23, FAST)
    long["cell23"] = r23["ok"] if r23["ok"] else r23["error"]
    long["cell23_error_names_record_id"] = bool(re.search(r"r\d{5}", long["cell23"])) if isinstance(long["cell23"], str) else None
    long["cell23_output_mentions_truncation"] = "truncat" in r23["out"].lower()
p5["over_ceiling_text"] = long
# Empty upload
FakeFiles.payload = {}
r = run_cell(ns, 17, {"USE_BYOD": True})
p5["empty_upload"] = r["ok"] if r["ok"] else r["error"]
record("P5_byod_intake", p5)

# ---- P6: BYOD downstream to Section 11 ------------------------------------------------------------
ns = fresh_namespace()
FakeFiles.payload = {"byod.csv": byod_payload({f"category {c}": 30 for c in range(3)})}
p6 = {}
for i in (17, 19, 21, 23, 25, 27, 29, 31):
    r = run_cell(ns, i, dict(FAST) if i == 23 else ({"USE_BYOD": True} if i == 17 else None))
    p6[i] = r["ok"] if r["ok"] else r["error"]
test_ids = {r["id"] for r in ns.get("test_records", [])}
p6["section11_new_records_are_test_records"] = all(
    any(n["text"] == t["text"] for t in ns["test_records"]) for n in ns.get("new_records", [])) if ns.get("new_records") else None
p6["section11_markdown_says"] = re.search(r"Ten messages that were in none of the splits", CELLS[30]) is not None
p6["section11_sample_kind"] = ns.get("new_report", {}).get("sample_kind") if isinstance(ns.get("new_report"), dict) else None
p6["new_ids"] = [r["id"] for r in ns.get("new_records", [])][:3]
record("P6_byod_downstream", p6)

shutil.rmtree(WORK, ignore_errors=True)
print("done")
